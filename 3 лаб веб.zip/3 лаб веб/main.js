import {
    books
} from "./data/books.js";


import {
    getVisibleBooks,
    getWishlistBooks
} from "./lib/books.js";


import {
    renderBookList,
    renderWishlist
} from "./ui/render.js";


// =========================
// DOM
// =========================

const form =
    document.querySelector(
        "#filter-form"
    );


const searchInput =
    document.querySelector(
        "#search"
    );


const genreSelect =
    document.querySelector(
        "#genre"
    );


const sortSelect =
    document.querySelector(
        "#sort"
    );


const availableCheckbox =
    document.querySelector(
        "#available"
    );


const resetButton =
    document.querySelector(
        "#reset-filters"
    );


const bookList =
    document.querySelector(
        "#book-list"
    );


const resultCount =
    document.querySelector(
        "#result-count"
    );


const emptyState =
    document.querySelector(
        "#empty-state"
    );


const wishlistList =
    document.querySelector(
        "#wishlist-list"
    );


const wishlistCount =
    document.querySelector(
        "#wishlist-count"
    );


const wishlistTotal =
    document.querySelector(
        "#wishlist-total"
    );


const wishlistEmpty =
    document.querySelector(
        "#wishlist-empty"
    );


// =========================
// LOCAL STORAGE
// =========================

function loadState() {

    try {

        const saved =
            localStorage.getItem(
                "booknest-state"
            );


        if (!saved) {

            return null;

        }


        return JSON.parse(saved);

    } catch (error) {

        console.warn(
            "Не удалось прочитать localStorage",
            error
        );


        return null;

    }

}


function saveState() {

    try {

        localStorage.setItem(
            "booknest-state",
            JSON.stringify(state)
        );

    } catch (error) {

        console.warn(
            "Не удалось сохранить состояние",
            error
        );

    }

}


// =========================
// STATE
// =========================

const savedState =
    loadState();


const state = {

    filters: {

        search:
            savedState?.filters?.search ?? "",

        genre:
            savedState?.filters?.genre ?? "all",

        sort:
            savedState?.filters?.sort ?? "default",

        availableOnly:
            savedState?.filters?.availableOnly ?? false

    },

    wishlist:
        Array.isArray(savedState?.wishlist)
            ? savedState.wishlist
            : []

};


// =========================
// RENDER
// =========================

function render() {

    const visibleBooks =
        getVisibleBooks(
            books,
            state.filters
        );


    const wishlistBooks =
        getWishlistBooks(
            books,
            state.wishlist
        );


    renderBookList(
        bookList,
        visibleBooks,
        state.wishlist
    );


    renderWishlist(
        wishlistList,
        wishlistBooks
    );


    resultCount.textContent =
        `Найдено книг: ${visibleBooks.length}`;


    emptyState.hidden =
        visibleBooks.length !== 0;


    wishlistCount.textContent =
        String(state.wishlist.length);


    wishlistTotal.textContent =
        String(state.wishlist.length);


    wishlistEmpty.hidden =
        state.wishlist.length !== 0;


    searchInput.value =
        state.filters.search;


    genreSelect.value =
        state.filters.genre;


    sortSelect.value =
        state.filters.sort;


    availableCheckbox.checked =
        state.filters.availableOnly;


    saveState();

}


// =========================
// ФИЛЬТРЫ
// =========================

function readFilters() {

    state.filters.search =
        searchInput.value;


    state.filters.genre =
        genreSelect.value;


    state.filters.sort =
        sortSelect.value;


    state.filters.availableOnly =
        availableCheckbox.checked;

}


// Одно событие формы
form.addEventListener(
    "input",
    () => {

        readFilters();

        render();

    }
);


form.addEventListener(
    "change",
    () => {

        readFilters();

        render();

    }
);


form.addEventListener(
    "submit",
    (event) => {

        event.preventDefault();

        readFilters();

        render();

    }
);


// =========================
// СБРОС
// =========================

resetButton.addEventListener(
    "click",
    () => {

        state.filters.search =
            "";

        state.filters.genre =
            "all";

        state.filters.sort =
            "default";

        state.filters.availableOnly =
            false;


        render();

    }
);


// =========================
// ДЕЛЕГИРОВАНИЕ КЛИКОВ
// =========================

document.addEventListener(
    "click",
    (event) => {

        const button =
            event.target.closest(
                "[data-action]"
            );


        if (!button) {

            return;

        }


        const id =
            Number(button.dataset.id);


        if (
            button.dataset.action ===
            "toggle-wishlist"
        ) {

            const exists =
                state.wishlist.includes(id);


            if (exists) {

                state.wishlist =
                    state.wishlist.filter(
                        (bookId) =>
                            bookId !== id
                    );

            } else {

                state.wishlist =
                    [
                        ...state.wishlist,
                        id
                    ];

            }


            render();

        }


        if (
            button.dataset.action ===
            "remove-wishlist"
        ) {

            state.wishlist =
                state.wishlist.filter(
                    (bookId) =>
                        bookId !== id
                );


            render();

        }

    }
);


// =========================
// ПЕРВЫЙ ЗАПУСК
// =========================

render();