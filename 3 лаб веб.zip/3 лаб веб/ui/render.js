function createElement(
    tag,
    className,
    text
) {

    const element =
        document.createElement(tag);


    if (className) {

        element.className =
            className;

    }


    if (text !== undefined) {

        element.textContent =
            text;

    }


    return element;
}


export function createBookCard(
    book,
    isWishlisted
) {

    const article =
        createElement(
            "article",
            "book-card"
        );


    article.dataset.id =
        String(book.id);


    const figure =
        createElement(
            "figure"
        );


    const image =
        createElement(
            "img",
            "book-card__image"
        );


    image.src =
        book.image;

    image.width =
        360;

    image.height =
        520;

    image.alt =
        `Обложка книги ${book.title}`;


    const caption =
        createElement(
            "figcaption",
            "",
            book.author
        );


    figure.append(
        image,
        caption
    );


    const title =
        createElement(
            "h3",
            "",
            book.title
        );


    const genre =
        createElement(
            "p",
            "",
            `Жанр: ${book.genreName}`
        );


    const year =
        createElement(
            "p",
            "",
            `Год: ${book.year}`
        );


    const rating =
        createElement(
            "p",
            "book-rating",
            `★ ${book.rating}`
        );


    const status =
        createElement(
            "p",
            "status",
            book.available
                ? "Доступна"
                : "Выдана"
        );


    if (!book.available) {

        status.classList.add(
            "status--unavailable"
        );

    }


    const wishlistButton =
        createElement(
            "button",
            "button wishlist-button",
            isWishlisted
                ? "✓ В моём списке"
                : "Хочу прочитать"
        );


    wishlistButton.type =
        "button";


    wishlistButton.dataset.action =
        "toggle-wishlist";


    wishlistButton.dataset.id =
        String(book.id);


    wishlistButton.setAttribute(
        "aria-pressed",
        String(isWishlisted)
    );


    if (isWishlisted) {

        wishlistButton.classList.add(
            "wishlist-button--active"
        );

    }


    article.append(
        figure,
        title,
        genre,
        year,
        rating,
        status,
        wishlistButton
    );


    return article;
}


export function renderBookList(
    container,
    books,
    wishlist
) {

    container.replaceChildren();


    books.forEach((book) => {

        const card =
            createBookCard(
                book,
                wishlist.includes(book.id)
            );


        container.append(card);

    });

}


export function renderWishlist(
    container,
    books
) {

    container.replaceChildren();


    books.forEach((book) => {

        const article =
            createElement(
                "article",
                "book-card"
            );


        article.dataset.id =
            String(book.id);


        const title =
            createElement(
                "h3",
                "",
                book.title
            );


        const author =
            createElement(
                "p",
                "",
                book.author
            );


        const button =
            createElement(
                "button",
                "button button--secondary",
                "Удалить из списка"
            );


        button.type =
            "button";


        button.dataset.action =
            "remove-wishlist";


        button.dataset.id =
            String(book.id);


        article.append(
            title,
            author,
            button
        );


        container.append(article);

    });

}